import { sign } from "jsonwebtoken";
import bcrypt from "bcryptjs";
import {
  DataStoredInToken,
  TokenData,
  User,
} from "../interfaces/users.interface";
import { AnyDocument } from "dynamoose/dist/Document";
import { HttpException } from "../../utils/error.utils";
import cmsModel from "../models/cms.model";
import { isEmpty } from "../../utils/create.util";
import Generator from "generate-password";
import { v4 as uuidv4 } from "uuid";

const UserModel = cmsModel[1]

const saltRounds = 10;

export default class UserService {
  public async logIn(email: string, password: string) {
    const userToFind = await UserModel.scan("Payload.email").eq(email).exec();
    const userInfo = userToFind[0].toJSON().Payload;
    const validPassword = await bcrypt.compare(password, userInfo.password);
    if (validPassword) {
      const tokenData = this.createToken(userToFind[0]);
      return { tokenData };
    } else {
      throw new HttpException(401, "Unsucessful login!!");
    }
  }

  public createToken(user: AnyDocument): TokenData {
    const dataStoredInToken: DataStoredInToken = { id: user.id };
    const secretKey: string = process.env.AWS_ACCESS_KEY_ID;
    const expiresIn: number = 30 * 30;

    return {
      expiresIn,
      token: sign(dataStoredInToken, secretKey, { expiresIn }),
    };
  }

  public async createUser(user: User) {
    const userId = uuidv4();
    const userToFind = await UserModel.scan("Payload.email")
      .eq(user.email)
      .exec();
    console.log(userToFind)
    if (isEmpty(user)) {
      throw new HttpException(400, "Didn't meet all the required fields");
    } else if (userToFind.count != 0) {
      throw new HttpException(409, `This email ${user.email} already exists.`);
    } else {
      const password = Generator.generate({
        length: 8,
        uppercase: true,
        symbols: true,
        numbers: true,
        lowercase: true,
      });
      console.log(password)
      bcrypt.genSalt(saltRounds, (err, salt) => {
        bcrypt.hash(password, salt, (err, hash) => {
          // Store hash in your password DB.
          UserModel.create({
            id: userId,
            pk: `USER#ALL`,
            sk: `USER#${userId}`,
            Payload: {
              username: user.username,
              email: user.email,
              gender: user.gender,
              password: hash,
              age: user.age,
            },
          });
        });
      });
    }
  }

  //   public async updateUser(id: string, user: User) {
  //     const exp = getDynamoExpression({
  //       Payload: {
  //         email: {
  //           $value: user.email,
  //         },
  //         username: {
  //           $value: user.username,
  //         },
  //         gender: {
  //           $value: user.gender,
  //         },
  //       },
  //     });
  //     console.log(exp);
  //     const params: UpdateItemInput = {
  //       TableName: process.env.DYNAMODB_TABLE,
  //       Key: {
  //         pk: { S: `USER#${id}` },
  //         sk: { S: `USER_AUTH#${id}` },
  //       },
  //       ExpressionAttributeNames:
  //         exp.ExpressionAttributeNames as ExpressionAttributeNameMap,
  //       UpdateExpression: exp.UpdateExpression as string,
  //       ExpressionAttributeValues:
  //         exp.ExpressionAttributeValues as ExpressionAttributeValueMap,
  //     };
  //     console.log(params);
  //     try {
  //       const data = await ddbClient.updateItem(params).promise();
  //       console.log("Success - item added or updated", data);
  //       return data;
  //     } catch (err) {
  //       console.log("Error", err);
  //     }
  //   }
}
