export interface Post{
    title:String,
    content:String
}