export interface UserLogin{
    email:String,
    password:String
}